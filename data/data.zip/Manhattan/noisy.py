import json
from copy import deepcopy
import numpy as np

with open('flow.json','r') as f:
    data = json.load(f)


for vehicle in data:
    assert vehicle['startTime'] == vehicle['endTime']


def valid_time(time):
    if time < 0:
        return 0
    elif time > 3600:
        return 3599
    else:
        return time


for i in range(1, 10):
    print(i)
    new_data = []
    for vehicle in data:
        new_car = vehicle.copy()
        startTime = valid_time(new_car['startTime'] + np.random.randint(-60, 60))
        endTime = startTime
        new_car['startTime'] = startTime
        new_car['endTime'] = endTime
        new_data.append(new_car)
    with open(f'flow_{i}.json','w') as f:
        json.dump(new_data, f)